#!/usr/bin/env node

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

const PORT = process.env.HASHKIT_PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, 'public');

// MIME types
const mimeTypes = {
    '.html': 'text/html',
    '.css': 'text/css',
    '.js': 'application/javascript',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
};

function getLocalIPs() {
    const interfaces = os.networkInterfaces();
    const ips = [];
    
    for (const name of Object.keys(interfaces)) {
        for (const net of interfaces[name]) {
            if (net.family === 'IPv4' && !net.internal) {
                ips.push(net.address);
            }
        }
    }
    
    // Always include localhost
    if (ips.length === 0) ips.push('127.0.0.1');
    
    return ips;
}

function serveFile(res, filePath, contentType) {
    fs.readFile(filePath, (err, data) => {
        if (err) {
            res.writeHead(404, { 'Content-Type': 'text/html' });
            res.end('<h1>404 - File Not Found</h1>');
            return;
        }
        res.writeHead(200, { 'Content-Type': contentType });
        res.end(data);
    });
}

const server = http.createServer((req, res) => {
    let filePath = req.url === '/' ? '/index.html' : req.url;
    filePath = path.join(PUBLIC_DIR, filePath);
    
    const ext = path.extname(filePath);
    const contentType = mimeTypes[ext] || 'application/octet-stream';
    
    // Security: prevent directory traversal
    if (!filePath.startsWith(PUBLIC_DIR)) {
        res.writeHead(403);
        res.end('Forbidden');
        return;
    }
    
    serveFile(res, filePath, contentType);
});

server.listen(PORT, '0.0.0.0', () => {
    const localIPs = getLocalIPs();
    
    console.log('\n╔══════════════════════════════════════════════════════════════╗');
    console.log('║                     🚀 HashKit Server Started                 ║');
    console.log('╠══════════════════════════════════════════════════════════════╣');
    console.log(`║  📱 Local Access:    http://127.0.0.1:${PORT}`);
    console.log(`║  📱 Local Access:    http://localhost:${PORT}`);
    
    if (localIPs[0] !== '127.0.0.1') {
        console.log(`║  🌐 Network Access:  http://${localIPs[0]}:${PORT}`);
    }
    
    console.log('║                                                              ║');
    console.log('║  💡 Tips:                                                    ║');
    console.log(`║    • Press Ctrl+C to stop the server                         ║`);
    console.log(`║    • Open your browser at: http://127.0.0.1:${PORT}               ║`);
    console.log('╚══════════════════════════════════════════════════════════════╝\n');
});

// Handle shutdown
process.on('SIGINT', () => {
    console.log('\n\n🛑 Shutting down HashKit server...');
    server.close(() => {
        console.log('✅ Server stopped. Goodbye! 👋\n');
        process.exit(0);
    });
});